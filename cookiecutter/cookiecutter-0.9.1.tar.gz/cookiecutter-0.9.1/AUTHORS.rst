=======
Credits
=======

Development Lead
----------------

* Audrey Roy <audreyr@gmail.com>

Core Committers
---------------

* Daniel Greenfeld (`@pydanny`_)
* Michael Joseph (`@michaeljoseph`_)
* Paul Moore (`@pfmoore`_)

Contributors
------------

* Steven Loria (`@sloria`_)
* Goran Peretin (`@gperetin`_)
* Hamish Downer (`@foobacca`_)
* Thomas Orozco (`@krallin`_)
* Jindrich Smitka (`@s-m-i-t-a`_)
* Benjamin Schwarze (`@benjixx`_)
* Raphi (`@raphigaziano`_)
* Thomas Chiroux (`@ThomasChiroux`_)
* Sergi Almacellas Abellana (`@pokoli`_)
* Alex Gaynor (`@alex`_)
* Rolo (`@rolo`_)
* Pablo (`@oubiga`_)
* Bruno Rocha (`@rochacbruno`_)
* Alexander Artemenko (`@svetlyak40wt`_)
* Mahmoud Abdelkader (`@mahmoudimus`_)
* Leonardo Borges Avelino (`@lborgav`_)
* Chris Trotman (`@solarnz`_)
* Rolf (`@relekang`_)
* Noah Kantrowitz (`@coderanger`_)
* Vincent Bernat (`@vincentbernat`_)
* Germán Moya (`@pbacterio`_)
* Ned Batchelder (`@nedbat`_)
* Dave Dash (`@davedash`_)
* Johan Charpentier (`@cyberj`_)
* Éric Araujo (`@merwok`_)
* Raphael Pierzina (`@hackebrot`_)
* saxix (`@saxix`_)
* Tzu-ping Chung (`@uranusjr`_)
* Caleb Hattingh (`@cjrh`_)
* Flavio Curella (`@fcurella`_)
* Adam Venturella (`@aventurella`_)
* Monty Taylor (`@emonty`_)
* schacki (`@schacki`_)
* Ryan Olson (`@ryanolson`_)
* Trey Hunner (`@treyhunner`_)
* Russell Keith-Magee (`@freakboy3742`_)
* Mishbah Razzaque (`@mishbahr`_)
* Robin Andeer (`@robinandeer`_)
* Rachel Sanders (`@trustrachel`_)
* Rémy Hubscher (`@Natim`_)
* Dino Petron3 (`@dinopetrone`_)
* Peter Inglesby (`@inglesp`_)
* Ramiro Batista da Luz (`@ramiroluz`_)
* Omer Katz (`@thedrow`_)

.. _`@vincentbernat`: https://github.com/vincentbernat
.. _`@audreyr`: https://github.com/audreyr
.. _`@pydanny`: https://github.com/pydanny
.. _`@sloria`: https://github.com/sloria
.. _`@gperetin`: https://github.com/gperetin
.. _`@foobacca`: https://github.com/foobacca
.. _`@krallin`: https://github.com/krallin
.. _`@s-m-i-t-a`: https://github.com/s-m-i-t-a
.. _`@benjixx`: https://github.com/benjixx
.. _`@raphigaziano`: https://github.com/raphigaziano
.. _`@ThomasChiroux`: https://github.com/ThomasChiroux
.. _`@pokoli`: https://github.com/pokoli
.. _`@alex`: https://github.com/alex
.. _`@rolo`: https://github.com/rolo
.. _`@oubiga`: https://github.com/oubiga
.. _`@michaeljoseph`: https://github.com/michaeljoseph
.. _`@rochacbruno`: https://github.com/rochacbruno
.. _`@svetlyak40wt`: https://github.com/svetlyak40wt
.. _`@mahmoudimus`: https://github.com/mahmoudimus
.. _`@lborgav`: https://github.com/lborgav
.. _`@solarnz`: https://github.com/solarnz
.. _`@relekang`: https://github.com/relekang
.. _`@coderanger`: https://github.com/coderanger
.. _`@pbacterio`: https://github.com/pbacterio
.. _`@nedbat`: https://github.com/nedbat
.. _`@davedash`: https://github.com/davedash
.. _`@cyberj`: https://github.com/cyberj
.. _`@merwok`: https://github.com/merwok
.. _`@hackebrot`: https://github.com/hackebrot
.. _`@saxix`: https://github.com/saxix
.. _`@uranusjr`: https://github.com/uranusjr
.. _`@cjrh`: https://github.com/cjrh
.. _`@pfmoore`: https://github.com/pfmoore
.. _`@fcurella`: https://github.com/fcurella
.. _`@aventurella`: https://github.com/aventurella
.. _`@emonty`: https://github.com/emonty
.. _`@schacki`: https://github.com/schacki
.. _`@ryanolson`: https://github.com/ryanolson
.. _`@treyhunner`: https://github.com/treyhunner 
.. _`@freakboy3742`: https://github.com/freakboy3742
.. _`@mishbahr`: https://github.com/mishbahr
.. _`@robinandeer`: https://github.com/robinandeer
.. _`@trustrachel`: https://github.com/trustrachel
.. _`@Natim`: https://github.com/Natim
.. _`@dinopetrone`: https://github.com/dinopetrone
.. _`@inglesp`: https://github.com/inglesp
.. _`@ramiroluz`: https://github.com/ramiroluz
.. _`@thedrow`: https://github.com/thedrow
